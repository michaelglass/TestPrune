# Replay format and parsing proposal

Each options file is a strict four-section text record:

1. `# Project: <path>`
2. `# SourceFiles (<count>):`, followed by exactly `<count>` lines
3. `# OtherOptions (<count>):`, followed by exactly `<count>` lines
4. `# ReferencedProjects (<count>):`, followed by exactly `<count>` lines

Every payload line begins with exactly two spaces. Strip those two characters,
not arbitrary whitespace, so option values remain stable. Reject a file when a
declared count, section order, placeholder, or SHA-256 differs from the
manifest. Do not parse paths by splitting on spaces.

For replay, expand `${CAPTURE_ROOT}` to the extracted `capture` directory,
`${DOTNET_ROOT}` to SDK 10.0.301, and `${NUGET_PACKAGES}` to a restored package
cache. For SourceFiles only, first probe
`${CAPTURE_ROOT}/external/nuget/<path relative to NUGET_PACKAGES>` and use that
bundled source when present. This makes the exact 82-file source cohort stable
while keeping framework/package DLLs out of the archive.

Build `FSharpProjectOptions` from the parsed project path, ordered SourceFiles,
and ordered OtherOptions. The captured project DLLs already occur as `-r:`
options; retain and validate the ReferencedProjects section as provenance. Feed
the target source text and these project options to FCS
`ParseAndCheckFileInProject`, then pass its `FSharpCheckFileResults` to
TestPrune's policy-aware analysis helper.

The always-on replay test performs both checks:

- A checked-in shape regression extracts this archive, verifies SHA-256 and
  counts, and parses the two primary files with the captured options.
- The semantic replay requires SDK 10.0.301 and the captured package versions
  restored. It asserts the known traversal measurements: 7,707 charged
  candidates for `TestPrunePlugin.fs` and 27,109 for
  `TestPrunePluginTests.fs`, both below the 32,768 hard cap.

The semantic replay was executed locally with SDK 10.0.301 and the captured
package versions already restored on 2026-08-29.

Archive generation sorts paths, omits extra platform metadata, and normalizes
ZIP entry timestamps to the portable 1980 floor so identical payloads produce
the same archive hash.
