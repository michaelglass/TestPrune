module FsHotWatch.Tests.CheckCacheTests

open System
open System.IO
open Xunit
open FsHotWatch.Events
open FsHotWatch.CheckCache
open FsHotWatch.InMemoryCheckCache
open FsHotWatch.Tests.TestHelpers

[<Fact(Timeout = 15000)>]
let ``CacheKey produces consistent hash for same inputs`` () =
    let key1 =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "def456" }

    let key2 =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "def456" }

    let hash1 = hashCacheKey key1
    let hash2 = hashCacheKey key2

    Assert.Equal(hash1, hash2)

[<Fact(Timeout = 15000)>]
let ``CacheKey produces different hash for different FileHash`` () =
    let key1 =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "def456" }

    let key2 =
        { FileHash = ContentHash.create "xyz789"
          ProjectOptionsHash = ContentHash.create "def456" }

    let hash1 = hashCacheKey key1
    let hash2 = hashCacheKey key2

    Assert.NotEqual<string>(hash1, hash2)

[<Fact(Timeout = 15000)>]
let ``CacheKey produces different hash for different ProjectOptionsHash`` () =
    let key1 =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "def456" }

    let key2 =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "xyz789" }

    let hash1 = hashCacheKey key1
    let hash2 = hashCacheKey key2

    Assert.NotEqual<string>(hash1, hash2)

[<Fact(Timeout = 15000)>]
let ``hash format is lowercase hex with no dashes`` () =
    let key =
        { FileHash = ContentHash.create "abc123"
          ProjectOptionsHash = ContentHash.create "def456" }

    let hash = hashCacheKey key

    Assert.Matches("^[a-f0-9]+$", hash)
    Assert.DoesNotContain("-", hash)

[<Fact(Timeout = 15000)>]
let ``TimestampCacheKeyProvider returns consistent hash for same file`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let tempFile = Path.GetTempFileName()
    File.WriteAllText(tempFile, "test content")

    try
        let hash1 = provider.GetFileHash(tempFile)
        let hash2 = provider.GetFileHash(tempFile)
        Assert.Equal<string option>(hash1, hash2)
        Assert.True(hash1.IsSome, "expected Some for readable file")
    finally
        File.Delete(tempFile)

[<Fact(Timeout = 20000)>]
let ``cache key is content-addressed: same bytes + different mtime → same hash`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let tempFile = Path.GetTempFileName()
    File.WriteAllText(tempFile, "stable content")

    try
        let hash1 = provider.GetFileHash(tempFile)

        // Bump mtime by ~2s without touching content. With timestamp-based
        // hashing this would produce a different hash; with content-addressed
        // hashing the bytes determine the key, so it must stay the same.
        System.Threading.Thread.Sleep(1100)
        File.SetLastWriteTimeUtc(tempFile, DateTime.UtcNow)

        let hash2 = provider.GetFileHash(tempFile)
        Assert.Equal<string option>(hash1, hash2)
    finally
        File.Delete(tempFile)

[<Fact(Timeout = 20000)>]
let ``TimestampCacheKeyProvider returns different hash after file modification`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let tempFile = Path.GetTempFileName()
    File.WriteAllText(tempFile, "original content")

    try
        let hash1 = provider.GetFileHash(tempFile)

        // Ensure mtime changes (some filesystems have 1s resolution)
        System.Threading.Thread.Sleep(1100)
        File.WriteAllText(tempFile, "modified content")

        let hash2 = provider.GetFileHash(tempFile)
        Assert.NotEqual<string option>(hash1, hash2)
    finally
        File.Delete(tempFile)

[<Fact(Timeout = 15000)>]
let ``TimestampCacheKeyProvider returns Some lowercase hex hash for readable file`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let tempFile = Path.GetTempFileName()
    File.WriteAllText(tempFile, "x")

    try
        match provider.GetFileHash(tempFile) with
        | Some hash ->
            Assert.Matches("^[a-f0-9]+$", hash)
            Assert.DoesNotContain("-", hash)
            Assert.True(hash.Length = 64)
        | None -> Assert.Fail "expected Some hash for readable file"
    finally
        File.Delete(tempFile)

[<Fact(Timeout = 15000)>]
let ``TimestampCacheKeyProvider returns None for unreadable file (F7: cache miss + retry)`` () =
    // F7 (docs/plans/2026-05-02-error-handling-audit.md): a synthesized
    // "unreadable:<path>" key lived forever in downstream caches, so a transient
    // lock that cleared on retry kept serving stale data. None forces a miss.
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let result = provider.GetFileHash("/nonexistent/test-f7.fs")
    Assert.True(result.IsNone, $"expected None for unreadable file, got %A{result}")

[<Fact(Timeout = 15000)>]
let ``makeCacheKey returns None when file is unreadable`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let checker = FsHotWatch.Tests.TestHelpers.sharedChecker.Value

    let opts, _ =
        checker.GetProjectOptionsFromScript(Path.GetTempFileName(), FSharp.Compiler.Text.SourceText.ofString "module A")
        |> Async.RunSynchronously

    let key = makeCacheKey provider "/nonexistent/missing-makeCacheKey.fs" opts
    Assert.True(key.IsNone, $"expected None CacheKey for unreadable file, got %A{key}")

[<Fact(Timeout = 15000)>]
let ``makeCacheKey produces different keys for different files`` () =
    let provider = TimestampCacheKeyProvider() :> ICacheKeyProvider
    let tempFile1 = Path.GetTempFileName()
    let tempFile2 = Path.GetTempFileName()
    File.WriteAllText(tempFile1, "content1")
    File.WriteAllText(tempFile2, "content2")

    let checker = FsHotWatch.Tests.TestHelpers.sharedChecker.Value

    let opts1, _ =
        checker.GetProjectOptionsFromScript(tempFile1, FSharp.Compiler.Text.SourceText.ofString "module A")
        |> Async.RunSynchronously

    let key1 = makeCacheKey provider tempFile1 opts1
    let key2 = makeCacheKey provider tempFile2 opts1

    try
        match key1, key2 with
        | Some k1, Some k2 -> Assert.NotEqual<string>(ContentHash.value k1.FileHash, ContentHash.value k2.FileHash)
        | _ -> Assert.Fail $"expected both Some, got %A{key1}, %A{key2}"
    finally
        File.Delete(tempFile1)
        File.Delete(tempFile2)

// --- InMemoryCheckCache tests ---

let private makeTestResult (file: string) (version: int64) : FileCheckResult =
    { File = AbsFilePath.create file
      Source = "test"
      ParseResults = Unchecked.defaultof<_>
      CheckResults = ParseOnly
      ProjectOptions = Unchecked.defaultof<_>
      Version = version }

let private makeKey (fileHash: string) : CacheKey =
    { FileHash = ContentHash.create fileHash
      ProjectOptionsHash = ContentHash.create "proj" }

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache stores and retrieves results`` () =
    let cache = InMemoryCheckCache(10) :> ICheckCacheBackend
    let key = makeKey "file1"
    let result = makeTestResult "test.fs" 1L

    cache.Set key result

    match cache.TryGet key with
    | Some r -> Assert.Equal(AbsFilePath.create "test.fs", r.File)
    | None -> Assert.Fail("Expected Some but got None")

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache returns None for missing key`` () =
    let cache = InMemoryCheckCache(10) :> ICheckCacheBackend
    let key = makeKey "nonexistent"

    Assert.True(cache.TryGet(key).IsNone)

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache evicts LRU on overflow`` () =
    let cache = InMemoryCheckCache(2) :> ICheckCacheBackend
    let key1 = makeKey "a"
    let key2 = makeKey "b"
    let key3 = makeKey "c"

    cache.Set key1 (makeTestResult "a.fs" 1L)
    cache.Set key2 (makeTestResult "b.fs" 2L)
    cache.Set key3 (makeTestResult "c.fs" 3L)

    Assert.True(cache.TryGet(key1).IsNone)
    Assert.True(cache.TryGet(key2).IsSome)
    Assert.True(cache.TryGet(key3).IsSome)

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache LRU access refreshes entry`` () =
    let cache = InMemoryCheckCache(2) :> ICheckCacheBackend
    let key1 = makeKey "a"
    let key2 = makeKey "b"
    let key3 = makeKey "c"

    cache.Set key1 (makeTestResult "a.fs" 1L)
    cache.Set key2 (makeTestResult "b.fs" 2L)
    // Access key1 to refresh it — key2 is now the LRU, so it loses the eviction.
    cache.TryGet key1 |> ignore
    cache.Set key3 (makeTestResult "c.fs" 3L)

    Assert.True(cache.TryGet(key1).IsSome)
    Assert.True(cache.TryGet(key2).IsNone)
    Assert.True(cache.TryGet(key3).IsSome)

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache invalidates entry`` () =
    let cache = InMemoryCheckCache(10) :> ICheckCacheBackend
    let key = makeKey "file1"

    cache.Set key (makeTestResult "test.fs" 1L)
    cache.Invalidate key

    Assert.True(cache.TryGet(key).IsNone)

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache updates existing key with new value`` () =
    let cache = InMemoryCheckCache(10) :> ICheckCacheBackend
    let key = makeKey "file1"

    cache.Set key (makeTestResult "test.fs" 1L)
    cache.Set key (makeTestResult "test.fs" 2L)

    match cache.TryGet key with
    | Some r -> Assert.Equal(2L, r.Version)
    | None -> Assert.Fail("Expected Some but got None")

[<Fact(Timeout = 15000)>]
let ``InMemoryCheckCache clear removes all entries`` () =
    let cache = InMemoryCheckCache(10) :> ICheckCacheBackend
    let key1 = makeKey "a"
    let key2 = makeKey "b"
    let key3 = makeKey "c"

    cache.Set key1 (makeTestResult "a.fs" 1L)
    cache.Set key2 (makeTestResult "b.fs" 2L)
    cache.Set key3 (makeTestResult "c.fs" 3L)

    cache.Clear()

    Assert.True(cache.TryGet(key1).IsNone)
    Assert.True(cache.TryGet(key2).IsNone)
    Assert.True(cache.TryGet(key3).IsNone)

// --- fcsCheckSignature ---

[<Fact(Timeout = 15000)>]
let ``fcsCheckSignature returns parse-only marker for ParseOnly`` () =
    let sig1 = fcsCheckSignature ParseOnly
    let sig2 = fcsCheckSignature ParseOnly
    Assert.Equal("parse-only", sig1)
    Assert.Equal(sig1, sig2)

[<Fact(Timeout = 15000)>]
let ``fcsCheckSignature differs between ParseOnly and FullCheck`` () =
    // Plugin caches must invalidate when FCS moves between parse-only and
    // full-check: the lint result depends on whether type info was available.
    let parseOnly = fcsCheckSignature ParseOnly
    let fullCheckNull = fcsCheckSignature (FullCheck(Unchecked.defaultof<_>))
    Assert.NotEqual<string>(parseOnly, fullCheckNull)

[<Fact(Timeout = 15000)>]
let ``fcsCheckSignature is stable across calls with same null FullCheck`` () =
    let s1 = fcsCheckSignature (FullCheck(Unchecked.defaultof<_>))
    let s2 = fcsCheckSignature (FullCheck(Unchecked.defaultof<_>))
    Assert.Equal(s1, s2)

// --- hashDiagnosticSignatures (extracted for testability without FCS) ---

let private mkSig line col errNo sev msg : DiagnosticSignature =
    { StartLine = line
      StartColumn = col
      ErrorNumber = errNo
      Severity = sev
      Message = msg }

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures empty sequence is stable`` () =
    let h1 = hashDiagnosticSignatures Seq.empty
    let h2 = hashDiagnosticSignatures Seq.empty
    Assert.Equal(h1, h2)

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures differs across distinct diagnostics`` () =
    let h1 = hashDiagnosticSignatures [ mkSig 1 2 100 "Error" "type mismatch" ]
    let h2 = hashDiagnosticSignatures [ mkSig 1 2 101 "Error" "type mismatch" ]
    Assert.NotEqual<string>(h1, h2)

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures is order-independent (sorted internally)`` () =
    let a = mkSig 1 2 100 "Error" "first"
    let b = mkSig 5 8 200 "Warning" "second"
    Assert.Equal(hashDiagnosticSignatures [ a; b ], hashDiagnosticSignatures [ b; a ])

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures distinguishes severity changes`` () =
    let warn = mkSig 1 2 100 "Warning" "msg"
    let err = mkSig 1 2 100 "Error" "msg"
    Assert.NotEqual<string>(hashDiagnosticSignatures [ warn ], hashDiagnosticSignatures [ err ])

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures distinguishes message text changes`` () =
    let a = mkSig 1 2 100 "Error" "type int but expected string"
    let b = mkSig 1 2 100 "Error" "type string but expected int"
    Assert.NotEqual<string>(hashDiagnosticSignatures [ a ], hashDiagnosticSignatures [ b ])

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticSignatures stable when same diagnostic list given twice`` () =
    let diags =
        [ mkSig 1 1 100 "Error" "a"
          mkSig 5 1 200 "Warning" "b"
          mkSig 10 1 300 "Info" "c" ]

    Assert.Equal(hashDiagnosticSignatures diags, hashDiagnosticSignatures diags)

// --- F1 regression: diagnostic-hash failures must not collide on a magic string ---

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticsOrFailure folds exception class so distinct failures don't collide`` () =
    // F1 (docs/plans/2026-05-02-error-handling-audit.md): returning the literal
    // "full-check-error" for every failure mode gave two distinct exceptions the
    // same downstream cache key. The payload now folds in the exception class.
    let throwInvalidOp () : DiagnosticSignature seq =
        raise (System.InvalidOperationException "boom-1")

    let throwArg () : DiagnosticSignature seq =
        raise (System.ArgumentException "boom-2")

    let h1 = hashDiagnosticsOrFailure throwInvalidOp
    let h2 = hashDiagnosticsOrFailure throwArg
    Assert.NotEqual<string>(h1, h2)
    Assert.NotEqual<string>("full-check-error", h1)
    Assert.NotEqual<string>("full-check-error", h2)

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticsOrFailure is deterministic across calls for the same failure`` () =
    let throwInvalidOp () : DiagnosticSignature seq =
        raise (System.InvalidOperationException "stable-message")

    let h1 = hashDiagnosticsOrFailure throwInvalidOp
    let h2 = hashDiagnosticsOrFailure throwInvalidOp
    Assert.Equal<string>(h1, h2)

[<Fact(Timeout = 2000)>]
let ``hashDiagnosticsOrFailure success path differs from any failure hash`` () =
    let success () : DiagnosticSignature seq = seq { mkSig 1 2 100 "Error" "ok" }

    let throwIo () : DiagnosticSignature seq = raise (System.IO.IOException "io-fail")

    Assert.NotEqual<string>(hashDiagnosticsOrFailure success, hashDiagnosticsOrFailure throwIo)
